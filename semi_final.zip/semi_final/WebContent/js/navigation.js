navigation.js


function changeBg(){
    var navbar = document.getElementById('navbar');
    var scrollValue = window.scrollY;
    console.log(scrollValue);

    
    if (scrollValue == 0||scrollValue < 899) {//1

        navbar.classList.remove('two_three');
        navbar.classList.remove('four');
    } else if (scrollValue > 900) {//2
        navbar.classList.add('two_three');
        navbar.classList.remove('nav');
    } else if (900<scrollValue&&scrollValue<2000) {//3
        navbar.classList.add('two_three');
        navbar.classList.remove('nav');
    }
    else if (scrollValue==2907){//4
        navbar.classList.remove('two_three');
        navbar.classList.add('nav');
    }
}

window.addEventListener('scroll',changeBg)