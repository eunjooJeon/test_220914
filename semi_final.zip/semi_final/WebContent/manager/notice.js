function check_ok() {
    if(notice_frm.n_title.value.length == 0) {
        alert("글 제목을 써주세요.");
		notice_frm.n_title.focus();
		return;
    }
    if(notice_frm.n_content.value.length == 0) {
        alert("내용을 써주세요.");
		notice_frm.n_content.focus();
		return;
	}
	
	document.notice_frm.submit();
}
