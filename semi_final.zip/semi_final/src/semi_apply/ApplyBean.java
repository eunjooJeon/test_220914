package semi_apply;

public class ApplyBean {
	private int ap_bidx;
	private String ap_id;
	private String ap_nickname;
	public int getAp_bidx() {
		return ap_bidx;
	}
	public void setAp_bidx(int ap_bidx) {
		this.ap_bidx = ap_bidx;
	}
	public String getAp_id() {
		return ap_id;
	}
	public void setAp_id(String ap_id) {
		this.ap_id = ap_id;
	}
	public String getAp_nickname() {
		return ap_nickname;
	}
	public void setAp_nickname(String ap_nickname) {
		this.ap_nickname = ap_nickname;
	}
	
}
