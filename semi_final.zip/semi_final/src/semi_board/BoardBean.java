package semi_board;

import java.sql.Timestamp;

//b_idx       NUMBER(4)       PRIMARY KEY,                        
//b_id        VARCHAR2(15)    REFERENCES SEMI_USERTABLE(u_id),     
//b_nickname  VARCHAR2(30)    NOT NULL,                           
//b_title     VARCHAR2(80)    NOT NULL,                            
//b_content   VARCHAR2(3000)  NOT NULL,                            
//b_date      DATE                    ,                           
//b_count     NUMBER(5)       DEFAULT 0,                           
//b_pwd       VARCHAR(12)     NOT NULL                       

public class BoardBean {

	private int b_idx;
	private String b_id;
	private String b_nickname;
	private String b_title;
	private String b_content;
	private Timestamp b_date;
	private int b_count;
	private String b_pwd;
	private int b_admindel;
	

	//	����¡
	public static int pageSize = 10;
	public static int pageCount = 1;
	public static int pageNum = 1;
	public static String pageNumber(int limit) {
		String str="";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		if((startPage - limit) > 0) {
			str="<a href='list.jsp?pageNum="+(startPage-1)+"'>[����]</a>&nbsp;&nbsp;";
		}		
		for(int i = startPage; i < (startPage+limit); i++) {
			if(i == pageNum) {
				str += "["+i+"]&nbsp;&nbsp;";
			} else {
				str += "<a href='list.jsp?pageNum="+i+"'>"+"["+i+"]</a>&nbsp;&nbsp;";
			}
			if(i >= pageCount) break;
		}		
		if((startPage + limit) <= pageCount) {
			str += "<a href='list.jsp?pageNum="+(startPage+limit)+"'>[����]";
		}
		return str;
	}
	public int getB_admindel() {
		return b_admindel;
	}

	public void setB_admindel(int b_admindel) {
		this.b_admindel = b_admindel;
	}
	
	public int getB_idx() {
		return b_idx;
	}
	public void setB_idx(int b_idx) {
		this.b_idx = b_idx;
	}
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public String getB_nickname() {
		return b_nickname;
	}
	public void setB_nickname(String b_nickname) {
		this.b_nickname = b_nickname;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public Timestamp getB_date() {
		return b_date;
	}
	public void setB_date(Timestamp b_date) {
		this.b_date = b_date;
	}
	public int getB_count() {
		return b_count;
	}
	public void setB_count(int b_count) {
		this.b_count = b_count;
	}
	public String getB_pwd() {
		return b_pwd;
	}
	public void setB_pwd(String b_pwd) {
		this.b_pwd = b_pwd;
	}
	
}
